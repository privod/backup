Description
===========

Module for configuration projects