from .main import Conf
__version__ = 1.0
__all__ = [
    'Conf'
]

__author__ = 'Nikolay Bespalov <nikolay_dvn@rambler.ru>'

